package com.example.demo.Model;

import javax.persistence.MappedSuperclass;
import javax.persistence.Id;
@MappedSuperclass
public class Person {
	@Id
	private String Id;
	private String Name;
	private int Experience;
	private String Address;
	private String Phone_number;
	
	public Person() {
		
	}

	public Person(String id, String name, int experience, String address, String phone_number) {
		super();
		Id = id;
		Name = name;
		Experience = experience;
		Address = address;
		Phone_number = phone_number;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public int getExperience() {
		return Experience;
	}

	public void setExperience(int experience) {
		Experience = experience;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getPhone_number() {
		return Phone_number;
	}

	public void setPhone_number(String phone_number) {
		Phone_number = phone_number;
	}
	
	
	
}
