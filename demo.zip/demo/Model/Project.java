package com.example.demo.Model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
@Entity
public class Project {
	@Id
	private int Id;
	private String name;
	private int Duration;
	private String Customer;
	
	@ManyToOne
	@JoinColumn(name = "manager_id",referencedColumnName = "Id")
	private Projectmanager manager;
	
	@OneToMany(mappedBy = "project")
	private List<Developer>developers;
	
	public Project() {
		
	}

	public Project(int id, String name, int duration, String customer, Projectmanager manager,
			List<Developer> developers) {
		super();
		Id = id;
		this.name = name;
		Duration = duration;
		Customer = customer;
		this.manager = manager;
		this.developers = developers;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getDuration() {
		return Duration;
	}

	public void setDuration(int duration) {
		Duration = duration;
	}

	public String getCustomer() {
		return Customer;
	}

	public void setCustomer(String customer) {
		Customer = customer;
	}

	public Projectmanager getManager() {
		return manager;
	}

	public void setManager(Projectmanager manager) {
		this.manager = manager;
	}

	public List<Developer> getDevelopers() {
		return developers;
	}

	public void setDevelopers(List<Developer> developers) {
		this.developers = developers;
	}
	
	
}
