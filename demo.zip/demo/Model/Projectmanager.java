package com.example.demo.Model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.OneToMany;

@Entity
public class Projectmanager extends Person{
	private String Skills;
	
	@OneToMany(mappedBy = "manager")
	private List <Project >project;
	
	public Projectmanager() {
		
	}

	public Projectmanager(String skills, List<Project> project) {
		super();
		Skills = skills;
		this.project = project;
	}

	public String getSkills() {
		return Skills;
	}

	public void setSkills(String skills) {
		Skills = skills;
	}

	public List<Project> getProject() {
		return project;
	}

	public void setProject(List<Project> project) {
		this.project = project;
	}
	
	
}

