package com.example.demo.Model;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Developer extends Person {
	private String programmingSkills;
	
	@ManyToOne
	@JoinColumn(name = "project_id",referencedColumnName = "Id")
	private Project project;
 
	public Developer() {
		
	}

	public Developer(String programmingSkills, Project project) {
		super();
		this.programmingSkills = programmingSkills;
		this.project = project;
	}

	public String getProgrammingSkills() {
		return programmingSkills;
	}

	public void setProgrammingSkills(String programmingSkills) {
		this.programmingSkills = programmingSkills;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}
	
	
}
