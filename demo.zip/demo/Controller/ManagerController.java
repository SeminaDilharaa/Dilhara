package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

import com.example.demo.Model.Projectmanager;
import com.example.demo.Repo.ManagerRepo;

@RestController
@RequestMapping("/manger")
public class ManagerController {
	@Autowired
	private ManagerRepo mangerepo;
	
	@GetMapping
	public ResponseEntity<List<Projectmanager>>getAll(){
		List<Projectmanager>managers=mangerepo.findAll();
		return new ResponseEntity<List<Projectmanager>>(managers,HttpStatus.FOUND);
	}
	
	@GetMapping("/name")
	public ResponseEntity<List<Projectmanager>>getByName(@PathVariable("Name") String Name){
		List<Projectmanager>managers=mangerepo.findByName(Name);
		return new ResponseEntity<List<Projectmanager>>(managers,HttpStatus.FOUND);
	}
	
}
/*
package com.practice.exercise.Controller;
package com.exercise.practice.Controller;

import java.util.List;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.practice.exercise.Model.Drug;
import com.practice.exercise.Repo.DrugRepo;
import com.exercise.practice.Model.Patient;
import com.exercise.practice.Repo.PatientRepo;

@RestController
@RequestMapping("/drug")
public class DrugController {
@RequestMapping("/patient")
public class PatientController {
	@Autowired
	private DrugRepo drugrepo;
	private PatientRepo patrepo;

	@GetMapping
	public List<Drug>getAll(){
		return drugrepo.findAll();
	public List<Patient>getAll(){
		return patrepo.findAll();
	}

	@GetMapping("/{id}")
	public Drug get(@PathVariable("id") String id) {
		return drugrepo.findById(id).get();
	public Patient get(@PathVariable("id") String id){
		return 	patrepo.findById(id).get();
	}

	@PostMapping
	public void add(@RequestBody Drug drug) {
		drugrepo.save(drug);
	public void add(@RequestBody Patient patient) {
		patrepo.save(patient);
	}

	@PutMapping
	public void update(@RequestBody Drug drug) {
		drugrepo.save(drug);
	public void update(@RequestBody Patient patient) {
		patrepo.save(patient);
	}

	@DeleteMapping("/{id}")
	public void delete(@PathVariable("id") String id) {
		drugrepo.deleteById(id);
	public void delete(@PathVariable("id") String id){
			patrepo.deleteById(id);
	}
}*/